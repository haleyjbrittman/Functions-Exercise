import UIKit
 

func sum(a: Int, b: Int) -> Int {
    return a + b
}
print ("Conclusion: \(sum (a: 5, b: 5) )")
